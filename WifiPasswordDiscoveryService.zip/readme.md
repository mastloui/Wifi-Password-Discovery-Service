# Overview
The Network Password Discovery Service allows you to rapidly get the password of the network you're computer is currently connected on.


> DISCLAIMER: This tool is not used to crack the password to wifi's you've never connected to.

# Installation
 
  1. Run install.bat.
  2. Restart your computer.


# Usage
Press CTRL + ALT + Q to automatically pop up the WIFI discovery window.

# Customization
If you want to change the key bindings for the shortcut, do the following:
  1. Go to the Startup - You can paste the following in an explorer window **%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs**
  2. Right click and open the Properties of the **Network Password Discovery.lnk** file.
  3. Go to the shortcut tab, click on the "Shortcut Key" field and enter your desired key bindings.